### Description

### Screenshots (if appropriate):


## Types of changes:
- [ ] Correct a spelling
- [ ] Add new information
- [ ] Change information

## Checklist:
- [ ] I have proofread the changes. (Spellings, grammar, etc)
- [ ] I have read the **CONTRIBUTING** document.