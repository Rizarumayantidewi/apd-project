# Overview <small> of Blocks</small>

* [Control](control.md)
* [Logic](logic.md)
* [Math](math.md)
* [Text](text.md)
* [Lists](lists.md)
* [Dictionaries](dictionaries.md)
* [Colors](colors.md)
* [Variables](variables.md)
* [Procedures](procedures.md)
* [Any Component](any-component.md)
