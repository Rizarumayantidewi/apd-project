# Overview <small>of LEGO® MINDSTORMS® > NXT</small>

* [NXT Color Sensor](nxt-color-sensor.md)
* [NXT Direct Commands](nxt-direct-commands.md)
* [NXT Drive](nxt-drive.md)
* [NXT Light Sensor](nxt-light-sensor.md)
* [NXT Sound Sensor](nxt-sound-sensor.md)
* [NXT Touch Sensor](nxt-touch-sensor.md)
* [NXT Ultrasonic Sensor](nxt-ultrasonic-sensor.md)