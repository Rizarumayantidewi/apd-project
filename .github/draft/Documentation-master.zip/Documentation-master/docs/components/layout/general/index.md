# Overview <small>of Layout > General</small>

* [Card View](card-view.md)
* [Grid View](grid-view.md)
* [Horizontal Arrangement](horizontal-arrangement.md)
* [Horizontal Scroll Arrangement](horizontal-scroll-arrangement.md)
* [Space](space.md)
* [Swipe Refresh Layout](swipe-refresh-layout.md)
* [Table Arrangement](table-arrangement.md)
* [Vertical Arrangement](vertical-arrangement.md)
* [Vertical Scroll Arrangement](vertical-scroll-arrangement.md)