# Concept Cards

!!! quote
    Big thanks to [@Peter](https://community.kodular.io/u/Peter) who made these amazing cards!

![Concept Card 1](/assets/images/other/resources/kodularconceptcard01.png)

![Concept Card 2](/assets/images/other/resources/kodularconceptcard02.png)

![Concept Card 3](/assets/images/other/resources/kodularconceptcard03.png)

![Concept Card 4](/assets/images/other/resources/kodularconceptcard04.png)

![Concept Card 5](/assets/images/other/resources/kodularconceptcard05.png)

![Concept Card 6](/assets/images/other/resources/kodularconceptcard06.png)

![Concept Card 7](/assets/images/other/resources/kodularconceptcard07.png)

![Concept Card 8](/assets/images/other/resources/kodularconceptcard08.png)

![Concept Card 9](/assets/images/other/resources/kodularconceptcard09.png)

![Concept Card 10](/assets/images/other/resources/kodularconceptcard10.png)

![Concept Card 11](/assets/images/other/resources/kodularconceptcard11.png)

![Concept Card 12](/assets/images/other/resources/kodularconceptcard12.png)

![Concept Card 13](/assets/images/other/resources/kodularconceptcard13.png)

![Concept Card 14](/assets/images/other/resources/kodularconceptcard14.png)

![Concept Card 15](/assets/images/other/resources/kodularconceptcard15.png)
