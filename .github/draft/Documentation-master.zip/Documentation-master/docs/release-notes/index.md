# Release Notes

## [1.0 Andromeda   \|   _22 June 2018_](andromeda.md)

## [1.1 Butterfly   \|   _19 August 2018_](butterfly.md)

## [1.2 Chamaeleon   \|   _26 October 2018_](chamaeleon.md)

## [1.3 Draco   \|   _13 January 2019_](draco.md)

## [1.4 Eagle   \|   _17 August 2019_](eagle.md)

## [1.5 Fenix   \|   _15 July 2021_](fenix.md)
