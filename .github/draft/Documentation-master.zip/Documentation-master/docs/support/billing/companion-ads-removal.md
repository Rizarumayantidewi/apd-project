# Companion Ads Removal

Some ads maybe shown in the [Kodular Companion](https://play.google.com/store/apps/details?id=io.makeroid.companion)
app on certain screens.  
(Please note that the ads are not included in the apps you create unless you add them, these ads are shown only in the
Home screen of the companion)  
They can be removed through a one-time purchase.  
To remove ads from the Companion, click the button in the title bar with the "$" icon.  
Changes will apply immediately, and  will be active lifelong as long as the same  Google Play account is used.
