# Overview <small> of Billing</small>

!!! warning
    All this section will change with the upcoming Kodular update. Please keep in mind these support
    pages may not be up-to-date.

* [Branding Removal](branding-removal.md)
* [Commission Removal](commission-removal.md)
* [Companion Ads Removal](companion-ads-removal.md)
* [Renewing a subscription](renewing-subscription.md)
* [Cancelling a subscription](cancelling-subscription.md)
* [Proration](proration.md)
* [Payment failed](payment-failed.md)
