# Overview <small> of Monetizing apps</small>

* [I have a question related to app development. How can I get help?](questions.md)