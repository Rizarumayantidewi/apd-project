# Do I need to get the app approved again, if I import a saved .aia copy of the same app from my computer?

Yes, you need to get the app reviewed and approved again in order to display ads in your app.
