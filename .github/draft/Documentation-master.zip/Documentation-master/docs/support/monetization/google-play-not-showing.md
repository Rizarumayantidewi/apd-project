# I have the app on the Google Play Store. But ads are not showing in the built APK.

If installed directly from an APK (while developing, perhaps) the ads might not be displayed.

Ads are shown automatically only when downloaded and installed through the Google Play Store.
