# I have the app on the Google Play Store. Does my app require approval for showing ads?

No, apps published on Google Play store need not request for approval.

Ads are automatically shown when the app is installed from Google Play Store.
