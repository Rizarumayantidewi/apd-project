# Overview <small> of My Account</small>

* [How to login into Kodular?](how-to-login.md)
* [I cannot use my 2FA codes, what can I do?](2fa-recovery.md)
* [Delete my Kodular Account](delete-account.md)
* [How to remove a credit/debit card from my account?](remove-payment-method.md)
* [How can I change my payment method?](change-payment-method.md)
