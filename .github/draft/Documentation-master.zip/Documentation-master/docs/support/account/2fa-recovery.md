# I cannot use my 2FA codes, what can I do?

If you get stuck in the 2-Factor Authentication screen, please send us an email to
[support-recovery@kodular.io](mailto:support-recovery@kodular.io).  
We will ask one of the 8 codes we sent to your email when you have activated this security measure.
