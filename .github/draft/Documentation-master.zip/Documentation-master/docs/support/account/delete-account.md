# Delete my Kodular Account

At this moment it is not possible to proceed with an automatic account deletion. In order to delete your
Kodular Account, you have to send us an email to [support-deletion@kodular.io](mailto:support-deletion@kodular.io)
asking to remove your Kodular Account.
We are so sad to see you go, please come back!
