# How can I change my payment method?

Payments are always charged on the card that you have set as the default one.  
So, in order to change the payment method, it would be enough to change the default card.  
You change the default card to an existing card, or if you can also add a new card and set that card the default one.
