# How to remove a credit/debit card from my account?

You can manage your card details from the [Billing](https://my.kodular.io/billing) section of My Kodular.  
Click on **_Payment methods_** to view the information about cards.

Please note that you will not be able to remove your default card when atleast one subscription is active.
